# CLEANLOOP Community – App Prototype

This is a browser-based interactive prototype created from the uploaded CLEANLOOP Community presentation.

Core screens:
- Citizen home / toilet health
- Nearby toilet map
- QR cleaning verification and issue reporting
- Worker dashboard and cleaning alerts
- Water management dashboard

The prototype reflects the PPT's concepts: smart toilet monitoring, consumable tracking, air-quality indication, QR verification, citizen navigation, greywater treatment/reuse, rainwater harvesting, green surroundings, and the Monitor → Detect → Alert → Assign → Clean → Verify → Update Map → Reuse Water → Improve cycle.

## Run
Open `index.html` in Chrome/Edge/Firefox.

## Hackathon demo flow
1. Open Home and show Toilet #04 health.
2. Open Map → Navigate Me.
3. Open QR/Report → Verify Cleaning / report an issue.
4. Open Worker → demonstrate alert and task completion.
5. Open Water → explain greywater/rainwater reuse.

This is a front-end prototype. Real ESP32/MQ sensors, GPS/maps, QR scanner, authentication, backend database and municipal dashboard would be connected in the production version.


## Access control
The Worker Dashboard is now protected:
- Citizens only see the normal citizen features.
- Selecting Worker Login opens a protected login screen.
- The Worker Dashboard cannot be opened without successful worker authentication.
- Demo worker PIN for the hackathon prototype: `123456`.
- In a real deployment, replace this demo PIN with secure authentication, worker accounts, role-based access control, and a backend session/token.


## Visual redesign – Premium CLEANLOOP
The UI was redesigned in the selected premium direction:
- Apple-style light interface
- Deep forest green + sage palette
- CLEANLOOP CL lettermark treatment
- Rounded premium cards and soft shadows
- Cleaner typography and spacing
- Sustainability hero section
- Worker login remains protected
